"""
build_report.py - assemble a self-contained, presentable HTML report or dashboard.
(Part of the industrial-report-builder skill: read SKILL.md and this docstring, then import this module. Do not rewrite it.)

WHEN: whenever the deliverable is an .html report, dashboard or readiness pack. A page of default-styled
tables is a failed run; this module makes the good version the easy one and refuses to save a thin page.

HOW:
  1. Compute every figure with pandas first and print the headline table. Never type a number you did not compute.
  2. Build the page from those numbers. Save with a contract; if it raises "FAILED RUN", fix the page.
  3. Report the counts that save() prints (tabs, charts, KPI cards) when you hand over.

    from build_report import Report, line_chart, bar_chart, stacked_bar, hbar, new_fig, fmt_num, fmt_money

    r = Report("Plant Executive Dashboard", "1 Jun - 29 Aug 2026  |  810 shifts, 3 lines", footer="Source: file, rows, definitions")
    r.banner("Week 13 is partial (6 of 7 days).", level="warn")          # every data caveat goes here, once
    r.kpis([dict(label="Plant OEE", value="90.1%", sub="weighted by operating time", status="good")])
    tabs = r.tabs()                                                       # or r.section("Title", lead="...") for one page
    t = tabs.tab("Director", lead="Two plain sentences: what this reader should do.")
    t.figure(bar_chart(lines, {"OEE %": oee}, "OEE (%)", "Line", color_by_label=True),
             "OEE by line", "Two sentences on what it means for the plant.")
    t.table(df, status_col="Status", filter_cols=["Line"], search=True, fmts={"Loss": fmt_money})
    r.save("report.html", require=dict(tabs=3, charts=5, kpis=4))         # prints counts; raises if too thin

BLOCKS: Report(title, subtitle, footer): .banner .kpis .section .tabs().tab(name, lead) .tally(name, n) .save(path, require=...)
  On a Tab/Section: .lead .h .text .bullets .callout(text, level) .kpis .figure(fig, title, caption, data=df) .table(...)
  Status chips take their icon and colour from the word (Release, Hold, Reject, Evidenced, Partly, Gap, Pass, Watch, Fail...).

SIGNATURES (positional order matters; every chart returns a figure for .figure()):
  line_chart(x_labels, {name: [values]}, ylabel, xlabel="", title=None, target=(value, "label") [one flat line, so only for a
             constant target], partial_from=0-based index of the first partial period, ylim=(lo, hi), yfmt=fn, gap_label="no data")
             None/NaN values become shaded gaps, never interpolated.
  bar_chart(labels, {name: [values]}, ylabel, xlabel="", title=None, fmt=fn, target=(value, "label"),
            color_by_label=False [True: each bar takes its entity colour], colors={name: hex})
  stacked_bar(labels, {name: [values]}, ylabel, xlabel="", title=None, fmt=fn, totals=True, colors={name: hex})
  hbar(labels, values, xlabel, title=None, fmt=fn, annotate=[text per bar], colors=[hex per bar], ylabel="")
       (xlabel is the axis under the bars; use colors= to grey out a baseline bar such as "clean-run baseline")
  Report.kpis([dict(label, value, sub=None, status="good"|"warn"|"bad"|None, status_label=text)]) - always pass status_label in the
       words of your domain ("Below target", "Hold"); the defaults are only OK / Attention / Problem.
  .table(df, columns=None, status_col="Status", status_map={"Closed late": "bad", "Outside the standard": "neutral"},
         filter_cols=["Line"], search=True, fmts={"Loss": fmt_money}, max_rows=None)
  Report.tally("notices", 7) registers a count the contract can require: save(require=dict(notices=7)).
  For a chart the helpers lack (timeline, scatter), use new_fig(w, h, ylabel, xlabel) -> (fig, ax) and draw on ax.
  Also importable: SERIES (8 fixed hues), STATUS (good/warning/serious/critical), color_for(name), AXIS, MUTED, fmt_num, fmt_money.
  A chip takes its colour from any word in the text (bad words win over warn over good): "Recommend Release" is green, "Partly
  evidenced" amber, "Recommend Reject" red; anything else is grey, or set it with status_map. Chips go with status_col only.
  Several caveats may share one banner call, or use several calls. Several r.section() calls are fine. partial_from already marks a
  partial period on a line chart, so don't rename the tick label. Do not judge a chip colour by the word alone: "Pass - closed by
  the wrong role" is a contradiction, so word the status truthfully.

RULES THE MODULE CANNOT ENFORCE:
  - Every chart has labelled axes with units and a two-sentence caption saying what it means. The card heading is the title.
  - Colour follows the entity (Line 1 is the same colour in every chart); a lone measure uses one colour; never dual axes.
  - Do not invent reference lines. A target or threshold on a chart must come from the data or the user's prompt.
  - Partial periods, missing data and unit conversions go in a banner and on the chart (dashed segment, "no data"
    band), not in a footnote.
  - If something is not derivable from the data, use the exact limitation sentence your own instructions give.

NEEDS: Python 3 + matplotlib (+ pandas if you pass DataFrames). No internet, no external scripts or fonts: charts are
embedded PNGs; tabs, filters and sorting use inline JavaScript. If you cannot run Python, stop and say so.
"""
import base64
import re
import html as _html
import io
import math

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter, MaxNLocator  # noqa: E402

# ------------------------------------------------------------------ palette
SURFACE = "#fcfcfb"
PAGE = "#f9f9f7"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
# Categorical slots, fixed order (validated adjacent-pair CVD-safe). Never cycled.
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
STATUS = {"good": "#0ca30c", "warning": "#fab219", "serious": "#ec835a", "critical": "#d03b3b"}

_entity_colors = {}


def color_for(name):
    """Colour follows the entity, not its rank: 'Line 1' is the same colour in every chart."""
    if name not in _entity_colors:
        _entity_colors[name] = SERIES[len(_entity_colors)] if len(_entity_colors) < len(SERIES) else MUTED
    return _entity_colors[name]


def _theme():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Segoe UI", "Helvetica Neue", "Arial", "DejaVu Sans"],
        "font.size": 9.5,
        "figure.facecolor": SURFACE,
        "axes.facecolor": SURFACE,
        "axes.edgecolor": AXIS,
        "axes.labelcolor": INK2,
        "xtick.color": INK2,
        "ytick.color": INK2,
        "text.color": INK2,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": False,
        "legend.frameon": False,
    })


_theme()


# ------------------------------------------------------------------ formatting
def fmt_num(x, dp=1):
    """1,284 / 12.9K / 4.2M"""
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "-"
    a = abs(x)
    if float(x).is_integer() and a < 1e4:
        return f"{int(x):,}"
    if a >= 1e6:
        return f"{x / 1e6:.{max(dp, 1)}f} mn"
    if a >= 1e4:
        return f"{x / 1e3:.{dp}f}K"
    if a >= 1000:
        return f"{x:,.0f}"
    return f"{x:,.{dp}f}" if a < 100 else f"{x:,.0f}"


def fmt_money(x, dp=1, cur="LKR "):
    return cur + fmt_num(x, dp)


# ------------------------------------------------------------------ chart helpers
def new_fig(w=7.6, h=3.5, ylabel=None, xlabel=None, title=None):
    """A styled empty figure for custom charts. Returns (fig, ax)."""
    fig, ax = plt.subplots(figsize=(w, h))
    _style(ax, ylabel, xlabel, title)
    return fig, ax


def _style(ax, ylabel=None, xlabel=None, title=None):
    for s in ("left", "bottom"):
        ax.spines[s].set_color(AXIS)
        ax.spines[s].set_linewidth(1)
    ax.yaxis.grid(True, color=GRID, linewidth=1)
    ax.set_axisbelow(True)
    ax.tick_params(length=0, labelsize=9)
    if ylabel:
        import textwrap
        ylabel = "\n".join(textwrap.wrap(ylabel, 34))
        ax.set_ylabel(ylabel, fontsize=9.5, color=INK2)
    if xlabel:
        ax.set_xlabel(xlabel, fontsize=9.5, color=INK2)
    # `title` is accepted for API symmetry but not drawn: Tab.figure() prints the card heading, so a
    # second title inside the image would just repeat it.
    if not ylabel and not xlabel:
        print("[report] warning: chart has no axis labels - label axes with units.")


def _legend(ax, n):
    if n >= 2:  # legend always present for 2+ series; none for one
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.5 if getattr(ax, "_rotated_x", False) else -0.16), ncol=min(n, 5), fontsize=9,
                  handlelength=1.4, labelcolor=INK2)


def _set_xlabels(ax, labels):
    """Set category labels; tilt them when there are many long ones so they never overprint."""
    ax.set_xticklabels(labels)
    if len(labels) > 6 and max(len(str(l)) for l in labels) > 9 and not any("\n" in str(l) for l in labels):
        plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
        ax._rotated_x = True


def _thin_ticks(ax, labels, max_ticks=14):
    n = len(labels)
    step = max(1, math.ceil(n / max_ticks))
    ax.set_xticks(range(0, n, step))
    ax.set_xticklabels([labels[i] for i in range(0, n, step)])


def line_chart(x_labels, series, ylabel, xlabel="", title=None, target=None, partial_from=None,
               ylim=None, yfmt=None, w=7.6, h=3.5, gap_label="no data"):
    """
    series: {name: [values]} - None/NaN become gaps and are shaded (labelled gap_label, default 'no data').
    target: (value, 'label') draws a thin reference line.
    partial_from: index of the first partial period; drawn dashed with a hollow end dot.
    """
    fig, ax = new_fig(w, h, ylabel, xlabel, title)
    n = len(x_labels)
    nan_idx = set()
    for name, vals in series.items():
        y = [float("nan") if (v is None or (isinstance(v, float) and math.isnan(v))) else float(v) for v in vals]
        nan_idx |= {i for i, v in enumerate(y) if math.isnan(v)}
        c = SERIES[0] if len(series) == 1 else color_for(name)
        k = partial_from if partial_from is not None else n
        ax.plot(range(min(k, n)), y[:k], color=c, linewidth=2, solid_capstyle="round", label=name)
        iso = [i for i, v in enumerate(y) if not math.isnan(v) and (i == 0 or math.isnan(y[i - 1])) and (i == n - 1 or math.isnan(y[i + 1]))]
        if iso:  # a lone point between gaps would otherwise be invisible
            ax.plot(iso, [y[i] for i in iso], "o", ms=8, mfc=c, mec=SURFACE, mew=2)
        last = max(i for i, v in enumerate(y[:k]) if not math.isnan(v)) if any(not math.isnan(v) for v in y[:k]) else None
        if partial_from is not None and partial_from < n:
            prev = max((i for i, v in enumerate(y[:k]) if not math.isnan(v)), default=None)
            if prev is not None and not math.isnan(y[partial_from]):
                ax.plot([prev, partial_from], [y[prev], y[partial_from]], color=c, linewidth=2, linestyle=(0, (3, 2)))
            if not math.isnan(y[partial_from]):
                ax.plot([partial_from], [y[partial_from]], "o", ms=8, mfc=SURFACE, mec=c, mew=2)
            if last is not None:
                ax.plot([last], [y[last]], "o", ms=8, mfc=c, mec=SURFACE, mew=2)
        elif last is not None:
            ax.plot([last], [y[last]], "o", ms=8, mfc=c, mec=SURFACE, mew=2)
    for i in sorted(nan_idx):
        ax.axvspan(i - 0.4, i + 0.4, color=MUTED, alpha=0.10, lw=0)
        ax.text(i, ax.get_ylim()[0], gap_label, rotation=90, va="bottom", ha="center", fontsize=8, color=MUTED)
    if partial_from is not None and partial_from < n:
        ax.text(partial_from, ax.get_ylim()[0], "partial week", ha="center", va="bottom", fontsize=8, color=MUTED)
    if target:
        ax.axhline(target[0], color=MUTED, linewidth=1)
        ax.text(-0.4, target[0], target[1], va="bottom", ha="left", fontsize=8.5, color=INK2)
    if ylim:
        ax.set_ylim(*ylim)
    if yfmt:
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: yfmt(v)))
    else:
        ax.yaxis.set_major_locator(MaxNLocator(nbins=6, integer=True))
    _thin_ticks(ax, x_labels)
    ax.set_xlim(-0.5, n - 0.5)
    _legend(ax, len(series))
    return fig


def bar_chart(labels, series, ylabel, xlabel="", title=None, fmt=None, target=None, w=7.6, h=3.5, color_by_label=False, colors=None):
    """Grouped columns. series: {name: [values]}. A value label sits on the cap for a single series.
    color_by_label=True colours each bar by its label (use when bars are lines/shifts/products that appear in other charts)."""
    fig, ax = new_fig(w, h, ylabel, xlabel, title)
    n = len(series)
    width = min(0.7 / n, 0.32)
    fmt = fmt or fmt_num
    for j, (name, vals) in enumerate(series.items()):
        xs = [i + (j - (n - 1) / 2) * (width + 0.03) for i in range(len(labels))]
        if colors and name in colors:
            col = colors[name]
        elif color_by_label:      # each bar is an entity (e.g. a line) that keeps its colour on every chart
            col = [color_for(l) for l in labels]
        else:                   # a lone measure is not an entity: one calm colour, series colours are for 2+ series
            col = SERIES[0] if n == 1 else color_for(name)
        bars = ax.bar(xs, vals, width=width, color=col, edgecolor=SURFACE, linewidth=1.2, label=name)
        if n == 1 and len(labels) <= 12:
            for b, v in zip(bars, vals):
                ax.text(b.get_x() + b.get_width() / 2, b.get_height(), fmt(v), ha="center", va="bottom", fontsize=8.5, color=INK2)
    ax.set_xticks(range(len(labels)))
    _set_xlabels(ax, labels)
    if target:
        ax.axhline(target[0], color=MUTED, linewidth=1)
        top = max(max(v) for v in series.values())
        ax.set_ylim(0, max(top, target[0]) * 1.15)
        ax.set_xlim(-0.5, len(labels) - 0.5)
        ax.text(len(labels) - 0.52, target[0] + max(top, target[0]) * 0.015, target[1], va="bottom", ha="right", fontsize=8.5, color=INK2)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: fmt(v)))
    if all(float(v).is_integer() for vals in series.values() for v in vals):
        ax.yaxis.set_major_locator(MaxNLocator(nbins=6, integer=True))
    _legend(ax, n)
    return fig


def stacked_bar(labels, series, ylabel, xlabel="", title=None, fmt=None, totals=True, w=7.6, h=3.5, colors=None):
    """Stacked columns with a 2px surface gap between segments. Totals sit on top.
    colors: optional {series_name: hex} override, e.g. {'Disrupted': STATUS['serious'], 'Clean': AXIS} for state series."""
    fig, ax = new_fig(w, h, ylabel, xlabel, title)
    fmt = fmt or fmt_num
    bottom = [0.0] * len(labels)
    for name, vals in series.items():
        ax.bar(range(len(labels)), vals, width=0.5, bottom=bottom, color=(colors or {}).get(name) or color_for(name), edgecolor=SURFACE, linewidth=1.5, label=name)
        bottom = [b + v for b, v in zip(bottom, vals)]
    if totals:
        for i, t in enumerate(bottom):
            ax.text(i, t, fmt(t), ha="center", va="bottom", fontsize=8.5, color=INK2)
    ax.set_xticks(range(len(labels)))
    _set_xlabels(ax, labels)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: fmt(v)))
    if all(float(v).is_integer() for vals in series.values() for v in vals):
        ax.yaxis.set_major_locator(MaxNLocator(nbins=6, integer=True))
    _legend(ax, len(series))
    return fig


def hbar(labels, values, xlabel, title=None, fmt=None, annotate=None, color=None, ylabel="", w=7.6, h=None, colors=None):
    """
    Horizontal bars in the order given (first at the top). Use for rankings and Pareto views.
    colors: optional per-bar colours (e.g. MUTED for a baseline bar that is not a fault).
    annotate: optional list of strings shown at the bar tip instead of the value, e.g. '$215K - 16%'.
    (No dual axis: put the cumulative or share figure in the annotation.)
    """
    h = h or max(2.4, 0.42 * len(labels) + 1.1)
    fig, ax = new_fig(w, h, ylabel or None, xlabel, title)
    fmt = fmt or fmt_num
    c = color or SERIES[0]
    ys = list(range(len(labels)))
    ax.barh(ys, values, height=0.5, color=colors or c, edgecolor=SURFACE, linewidth=1)
    ax.set_yticks(ys)
    ax.set_yticklabels(labels)
    ax.invert_yaxis()
    ax.xaxis.grid(True, color=GRID, linewidth=1)
    ax.yaxis.grid(False)
    top = max(values) if len(values) else 1
    for y, v, a in zip(ys, values, annotate or [None] * len(values)):
        ax.text(v + top * 0.01, y, a or fmt(v), va="center", ha="left", fontsize=8.5, color=INK2)
    ax.set_xlim(0, top * 1.22)
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: fmt(v)))
    return fig


def _png_b64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=170, facecolor=SURFACE, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode("ascii")


# ------------------------------------------------------------------ HTML pieces
_e = _html.escape

_CHIP = [  # (keywords, css class, icon, default label)
    (("reject", "fail", "gap", "red", "critical", "breach", "overdue", "lapsed", "missing", "not", "no", "expired", "quarantine", "invalid", "wrong"), "bad", "✕"),
    (("hold", "partly", "partial", "amber", "watch", "at risk", "warning", "late", "query", "open"), "warn", "!"),
    (("release", "evidenced", "ok", "pass", "green", "good", "compliant", "closed", "done", "valid"), "good", "✓"),
]


def _chip(text, status=None):
    t = str(text)
    low = t.lower()
    cls, icon = "neutral", "–"
    if status in ("good", "green"):
        cls, icon = "good", "✓"
    elif status in ("warn", "amber", "warning"):
        cls, icon = "warn", "!"
    elif status in ("bad", "red", "critical"):
        cls, icon = "bad", "✕"
    elif status == "neutral":
        cls, icon = "neutral", "–"
    elif status is None:
        words = set(re.findall(r"[a-z]+", low))
        for keys, c, i in _CHIP:
            if any(k in words for k in keys):
                cls, icon = c, i
                break
    return f'<span class="chip {cls}"><span class="ic" aria-hidden="true">{icon}</span>{_e(t)}</span>'


def _cell(v, col, fmts):
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return "—"
    if not isinstance(v, (list, tuple, dict, set, str, bool, int, float)):
        try:  # pandas NaT / Timestamp
            import pandas as _pd
            if _pd.isna(v):
                return "—"
            if isinstance(v, _pd.Timestamp):
                return _e(v.strftime("%Y-%m-%d") if (v.hour == 0 and v.minute == 0) else v.strftime("%Y-%m-%d %H:%M"))
        except Exception:
            pass
    f = fmts.get(col) if fmts else None
    if callable(f):
        return _e(str(f(v)))
    if isinstance(f, str):
        return _e(f.format(v))
    if isinstance(v, bool):
        return "Yes" if v else "No"
    if isinstance(v, float):
        return _e(f"{v:,.0f}" if abs(v) >= 1000 else f"{v:,.2f}")
    if isinstance(v, int):
        return _e(f"{v:,}") if abs(v) >= 10000 else _e(str(v))
    return _e(str(v))


def _rows_cols(data, columns):
    if hasattr(data, "to_dict") and hasattr(data, "columns"):
        rows = data.to_dict("records")
        cols = list(columns or data.columns)
    else:
        rows = list(data)
        cols = list(columns or (rows[0].keys() if rows else []))
    return rows, cols


class _Block:
    """Shared content methods for Section and Tab."""

    def __init__(self, report):
        self._r = report
        self._h = []

    # text
    def lead(self, text):
        self._h.append(f'<p class="lead">{_e(text)}</p>')
        return self

    def h(self, text):
        self._h.append(f"<h3>{_e(text)}</h3>")
        return self

    def text(self, text, raw=False):
        self._h.append(f'<p>{text if raw else _e(text)}</p>')
        return self

    def bullets(self, items, raw=False):
        self._h.append("<ul>" + "".join(f"<li>{i if raw else _e(i)}</li>" for i in items) + "</ul>")
        return self

    def callout(self, text, level="info"):
        self._h.append(f'<div class="banner {level}">{_e(text)}</div>')
        return self

    # numbers
    def kpis(self, cards):
        self._h.append(self._r._kpi_html(cards))
        return self

    # charts
    def figure(self, fig, title, caption="", data=None, alt=None):
        """fig: a matplotlib figure from this module (or PNG bytes). caption = two sentences on what it means."""
        b64 = _png_b64(fig) if not isinstance(fig, (bytes, bytearray)) else base64.b64encode(fig).decode("ascii")
        self._r._n_charts += 1
        det = ""
        if data is not None:
            det = '<details class="tv"><summary>View data</summary>' + self._table_html(data, None, None, (), False, None, None, False) + "</details>"
        self._h.append(
            f'<figure class="chart"><h4>{_e(title)}</h4>'
            f'<img alt="{_e(alt or title)}" src="data:image/png;base64,{b64}">'
            f'<figcaption>{_e(caption)}</figcaption>{det}</figure>'
        )
        return self

    # tables
    def _table_html(self, data, columns, status_col, filter_cols, search, fmts, max_rows, sortable=True, status_map=None):
        rows, cols = _rows_cols(data, columns)
        if max_rows:
            rows = rows[:max_rows]
        self._r._tid += 1
        tid = f"t{self._r._tid}"
        ctl = ""
        if search or filter_cols:
            ctl = '<div class="tctl">'
            if search:
                ctl += f'<input type="search" class="tsearch" placeholder="Search" aria-label="Search table" data-t="{tid}">'
            for fc in filter_cols:
                vals = sorted({str(r.get(fc, "")) for r in rows})
                opts = '<option value="">All ' + _e(fc) + "</option>" + "".join(f'<option>{_e(v)}</option>' for v in vals)
                ctl += f'<select class="tfilter" data-t="{tid}" data-col="{_e(fc)}" aria-label="Filter {_e(fc)}">{opts}</select>'
            ctl += f'<span class="tcount" id="{tid}-n"></span></div>'
        th = "".join(f'<th{" class=sortable" if sortable else ""} scope="col">{_e(str(c))}</th>' for c in cols)
        body = []
        for r in rows:
            tds, attrs = [], ""
            for c in cols:
                v = r.get(c)
                attrs += f' data-{_slug(c)}="{_e(str(v))}"'
                if c == status_col:
                    tds.append(f"<td>{_chip(v, (status_map or {}).get(str(v)))}</td>")
                else:
                    num = isinstance(v, (int, float)) and not isinstance(v, bool)
                    tds.append(f'<td class="{"num" if num else ""}">{_cell(v, c, fmts)}</td>')
            body.append(f"<tr{attrs}>{''.join(tds)}</tr>")
        return f'<div class="tbl" id="{tid}">{ctl}<div class="scroll"><table class="data"><thead><tr>{th}</tr></thead><tbody>{"".join(body)}</tbody></table></div></div>'

    def table(self, data, columns=None, status_col=None, filter_cols=(), search=False, fmts=None, max_rows=None, caption=None, status_map=None):
        """data: DataFrame or list of dicts. status_col renders coloured chips (icon + label); status_map={"Closed late": "bad"} overrides the colour for
        a given text ("good", "warn", "bad", "neutral"). Filterable/sortable in the browser."""
        self._r._n_tables += 1
        if caption:
            self._h.append(f'<p class="tcap">{_e(caption)}</p>')
        self._h.append(self._table_html(data, columns, status_col, filter_cols, search, fmts, max_rows, True, status_map))
        return self

    def html(self):
        return "".join(self._h)


def _slug(s):
    return "".join(ch.lower() if ch.isalnum() else "-" for ch in str(s))


class Section(_Block):
    def __init__(self, report, title, lead=None):
        super().__init__(report)
        self.title = title
        if lead:
            self.lead(lead)

    def render(self):
        return f'<section class="sec"><h2>{_e(self.title)}</h2>{self.html()}</section>'


class Tab(_Block):
    def __init__(self, report, name, lead=None):
        super().__init__(report)
        self.name = name
        if lead:
            self.lead(lead)


class TabGroup:
    def __init__(self, report):
        self._r = report
        self.items = []

    def tab(self, name, lead=None):
        t = Tab(self._r, name, lead)
        self.items.append(t)
        return t

    def render(self):
        gid = f"g{id(self) % 100000}"
        nav = "".join(
            f'<button role="tab" class="tabbtn{" on" if i == 0 else ""}" data-g="{gid}" data-i="{i}" aria-selected="{"true" if i == 0 else "false"}">{_e(t.name)}</button>'
            for i, t in enumerate(self.items))
        panels = "".join(
            f'<div role="tabpanel" class="panel{" on" if i == 0 else ""}" data-g="{gid}" data-i="{i}"><h2 class="ptitle">{_e(t.name)}</h2>{t.html()}</div>'
            for i, t in enumerate(self.items))
        return f'<div class="tabs"><div class="tabnav" role="tablist">{nav}</div>{panels}</div>'


_CSS = """
:root{--surface:#fcfcfb;--page:#f9f9f7;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;--grid:#e1e0d9;--axis:#c3c2b7;--ring:rgba(11,11,11,.10);--blue:#2a78d6}
*{box-sizing:border-box}
body{margin:0;background:var(--page);color:var(--ink);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}
.wrap{max-width:1120px;margin:0 auto;padding:28px 20px 64px}
header h1{font-size:28px;line-height:1.2;margin:0 0 4px;font-weight:650}
.sub{color:var(--ink2);margin:0 0 14px}
h2{font-size:20px;margin:30px 0 8px;font-weight:650}
h3{font-size:16px;margin:20px 0 6px}
h4{font-size:14px;margin:0 0 8px;font-weight:650}
.lead{font-size:16.5px;color:var(--ink);margin:6px 0 14px;max-width:80ch}
p{max-width:90ch}
.banner{border-left:4px solid var(--muted);background:#f0efec;padding:10px 14px;margin:10px 0;border-radius:6px;font-size:14px}
.banner.warn{border-color:#fab219;background:#fff6dd}.banner.bad{border-color:#d03b3b;background:#fdecec}.banner.info{border-color:#2a78d6;background:#eaf2fc}.banner.good{border-color:#0ca30c;background:#e9f6e9}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;margin:16px 0}
.card{background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:14px 16px;border-left:4px solid var(--axis)}
.card.good{border-left-color:#0ca30c}.card.warn{border-left-color:#fab219}.card.bad{border-left-color:#d03b3b}
.card .label{color:var(--ink2);font-size:13px}
.card .value{font-size:30px;font-weight:650;line-height:1.15;margin:2px 0}
.card .sub2{color:var(--ink2);font-size:12.5px;margin-top:2px}
.chip{display:inline-flex;align-items:center;gap:5px;padding:1px 9px;border-radius:999px;font-size:12.5px;font-weight:600;white-space:nowrap}
.chip .ic{font-size:11px}
.chip.good{background:#e3f4e3;color:#005e00}.chip.warn{background:#fff0c9;color:#6f4a00}.chip.bad{background:#fbe1e1;color:#9c2222}.chip.neutral{background:#eceae4;color:var(--ink2)}
.tabnav{display:flex;gap:4px;border-bottom:1px solid var(--axis);margin:22px 0 4px;flex-wrap:wrap}
.tabbtn{appearance:none;border:0;background:none;padding:10px 16px;font:inherit;font-weight:600;color:var(--ink2);cursor:pointer;border-bottom:3px solid transparent;margin-bottom:-1px}
.tabbtn:hover{color:var(--ink)}.tabbtn.on{color:var(--ink);border-bottom-color:var(--blue)}
.tabbtn:focus-visible,.tsearch:focus-visible,.tfilter:focus-visible{outline:2px solid var(--blue);outline-offset:2px}
.panel{display:none}.panel.on{display:block}.ptitle{display:none}
.charts,.sec>figure,.panel>figure{}
figure.chart{margin:16px 0;background:var(--surface);border:1px solid var(--ring);border-radius:10px;padding:14px 16px}
figure.chart img{width:100%;height:auto;display:block}
figcaption{color:var(--ink2);font-size:14px;margin-top:8px;max-width:90ch}
details.tv{margin-top:8px;font-size:13px}details.tv summary{cursor:pointer;color:var(--ink2)}
.tbl{margin:12px 0 20px}.scroll{overflow-x:auto;border:1px solid var(--ring);border-radius:10px;background:var(--surface)}
table.data{border-collapse:collapse;width:100%;font-size:13.5px}
table.data th{text-align:left;padding:9px 12px;color:var(--ink2);font-weight:600;border-bottom:1px solid var(--axis);background:#f4f3ef;white-space:nowrap}
table.data th.sortable{cursor:pointer}table.data th.sortable:hover{color:var(--ink)}
table.data td{padding:8px 12px;border-bottom:1px solid var(--grid);vertical-align:top}
table.data tr:last-child td{border-bottom:0}
td.num{text-align:right;font-variant-numeric:tabular-nums}
.tctl{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:8px}
.tsearch,.tfilter{font:inherit;font-size:13.5px;padding:6px 10px;border:1px solid var(--axis);border-radius:8px;background:var(--surface);color:var(--ink)}
.tcount{color:var(--ink2);font-size:13px}
.tcap{color:var(--ink2);font-size:13.5px;margin:14px 0 2px}
footer{margin-top:40px;color:var(--muted);font-size:12.5px;border-top:1px solid var(--grid);padding-top:12px}
@media (max-width:640px){.wrap{padding:18px 12px 48px}header h1{font-size:23px}.card .value{font-size:26px}}
@media print{body{background:#fff}.tabnav,.tctl{display:none}.panel{display:block!important}.ptitle{display:block}figure.chart,.card,.scroll{break-inside:avoid}.wrap{padding:0}}
"""

_JS = """
(function(){
function q(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));}
q('.tabbtn').forEach(function(b){b.addEventListener('click',function(){
  var g=b.getAttribute('data-g'),i=b.getAttribute('data-i');
  q('.tabbtn[data-g="'+g+'"]').forEach(function(x){var on=x.getAttribute('data-i')===i;x.classList.toggle('on',on);x.setAttribute('aria-selected',on?'true':'false');});
  q('.panel[data-g="'+g+'"]').forEach(function(p){p.classList.toggle('on',p.getAttribute('data-i')===i);});
});});
function slug(s){return s.toLowerCase().replace(/[^a-z0-9]/g,'-');}
function apply(id){
  var box=document.getElementById(id);if(!box)return;
  var s=box.querySelector('.tsearch'),term=s?s.value.toLowerCase():'';
  var fs=q('.tfilter',box),shown=0,rows=q('tbody tr',box);
  rows.forEach(function(r){
    var ok=!term||r.textContent.toLowerCase().indexOf(term)>-1;
    fs.forEach(function(f){var v=f.value;if(v&&r.getAttribute('data-'+slug(f.getAttribute('data-col')))!==v)ok=false;});
    r.style.display=ok?'':'none';if(ok)shown++;
  });
  var n=document.getElementById(id+'-n');if(n)n.textContent=shown+' of '+rows.length;
}
q('.tsearch,.tfilter').forEach(function(c){c.addEventListener('input',function(){apply(c.getAttribute('data-t'));});});
q('.tbl').forEach(function(b){apply(b.id);});
q('th.sortable').forEach(function(th){th.addEventListener('click',function(){
  var t=th.closest('table'),i=th.cellIndex,tb=t.tBodies[0],rows=Array.prototype.slice.call(tb.rows);
  var dir=th.getAttribute('data-dir')==='asc'?'desc':'asc';
  q('th',t).forEach(function(x){x.removeAttribute('data-dir');});th.setAttribute('data-dir',dir);
  rows.sort(function(a,b){
    var x=a.cells[i].textContent.trim(),y=b.cells[i].textContent.trim();
    var nx=parseFloat(x.replace(/[^0-9.\\-]/g,'')),ny=parseFloat(y.replace(/[^0-9.\\-]/g,''));
    var r=(!isNaN(nx)&&!isNaN(ny)&&/^[\\-$0-9]/.test(x))?nx-ny:x.localeCompare(y);
    return dir==='asc'?r:-r;});
  rows.forEach(function(r){tb.appendChild(r);});
});});
})();
"""


class Report:
    def __init__(self, title, subtitle=None, footer=None):
        self.title, self.subtitle, self.footer = title, subtitle, footer
        self._banners, self._items = [], []
        self._n_charts = self._n_tables = self._n_kpis = 0
        self._extra = {}
        self._tid = 0

    # ---- top-level content
    def banner(self, text, level="warn"):
        """Status banner for data caveats (level: warn, bad, info, good). Put every caveat here."""
        self._banners.append(f'<div class="banner {level}">{_e(text)}</div>')
        return self

    def _kpi_html(self, cards):
        out = []
        for c in cards:
            self._n_kpis += 1
            st = c.get("status")
            cls = {"good": "good", "green": "good", "warn": "warn", "amber": "warn", "bad": "bad", "red": "bad"}.get(st, "")
            chip = _chip(c.get("status_label", {"good": "OK", "green": "OK", "warn": "Attention", "amber": "Attention", "bad": "Problem", "red": "Problem"}.get(st, "")), st) if st else ""
            sub = f'<div class="sub2">{_e(c["sub"])}</div>' if c.get("sub") else ""
            out.append(f'<div class="card {cls}"><div class="label">{_e(c["label"])}</div><div class="value">{_e(str(c["value"]))}</div>{sub}<div style="margin-top:6px">{chip}</div></div>')
        return '<div class="kpis">' + "".join(out) + "</div>"

    def kpis(self, cards):
        """cards: list of dict(label, value, sub=None, status='good'|'warn'|'bad'|None, status_label=None). Status shows icon + word, never colour alone."""
        self._items.append(("raw", self._kpi_html(cards)))
        return self

    def section(self, title, lead=None):
        s = Section(self, title, lead)
        self._items.append(("obj", s))
        return s

    def tabs(self):
        g = TabGroup(self)
        self._items.append(("obj", g))
        return g

    def tally(self, name, n):
        """Register a count the contract can require, e.g. r.tally('notices', 7); then save(require=dict(notices=7))."""
        self._extra[name] = n
        return self

    # ---- output
    def counts(self):
        tabs = sum(len(o.items) for k, o in self._items if k == "obj" and isinstance(o, TabGroup))
        secs = sum(1 for k, o in self._items if k == "obj" and isinstance(o, Section))
        return dict(tabs=tabs, sections=secs, charts=self._n_charts, tables=self._n_tables, kpis=self._n_kpis, banners=len(self._banners), **self._extra)

    def check(self, **require):
        """Contract check, e.g. check(tabs=3, charts=5, kpis=4). Raises AssertionError describing a failed run."""
        c = self.counts()
        bad = [f"{k}: need at least {v}, have {c.get(k, 0)}" for k, v in require.items() if c.get(k, 0) < v]
        if bad:
            raise AssertionError("FAILED RUN - this report does not meet its contract (" + "; ".join(bad) + "). Do not ship it; fix it.")
        return c

    def render(self):
        body = []
        for kind, o in self._items:
            body.append(o if kind == "raw" else o.render())
        head = f'<header><h1>{_e(self.title)}</h1>' + (f'<p class="sub">{_e(self.subtitle)}</p>' if self.subtitle else "") + "</header>"
        foot = f"<footer>{_e(self.footer)}</footer>" if self.footer else ""
        return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                f'<title>{_e(self.title)}</title><style>{_CSS}</style></head><body><div class="wrap">{head}{"".join(self._banners)}{"".join(body)}{foot}</div><script>{_JS}</script></body></html>')

    def save(self, path, require=None):
        """Write the file. Pass require=dict(tabs=3, charts=5, ...) to refuse a thin report. Prints and returns the counts."""
        c = self.check(**(require or {}))
        with open(path, "w", encoding="utf-8") as f:
            f.write(self.render())
        print(f"[report] saved {path}: " + ", ".join(f"{v} {k}" for k, v in c.items()))
        return c
