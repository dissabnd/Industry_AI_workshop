---
name: industrial-report-builder
description: "Builds presentable, self-contained HTML reports and dashboards (KPI cards, tabs, charts, filterable tables, status chips) from plant, quality or audit data using a tested Python module. Use whenever the deliverable is an .html report, dashboard, readiness pack or leadership pack, so the result is never a page of plain tables."
---

# Industrial report builder

A page of default-styled tables is a failed run. This skill gives you a tested Python module, `build_report.py` (in this skill's folder), that turns numbers you have already computed into a finished page: header, KPI cards, tabs or sections, charts, filterable tables and status chips. It also refuses to save a page that is too thin.

## When to use it

Whenever your task asks for an `.html` report, dashboard or pack. Follow your own task instructions for what the report must contain; this skill only handles how it is laid out and styled.

## Set-up

Python 3 with `matplotlib` (and `pandas` if you pass DataFrames). No internet, no external scripts or fonts: charts are embedded PNGs; tabs, filters and sorting use inline JavaScript.

Make the module importable from this skill's folder:

```python
import sys
sys.path.insert(0, "<folder that contains build_report.py>")   # this skill's folder
from build_report import Report, line_chart, bar_chart, stacked_bar, hbar, new_fig, fmt_num, fmt_money
```

If you cannot import it, open `build_report.py`, run its contents in your Python session first, then continue. Do not rewrite it. If you cannot run Python at all, stop and say so; do not hand-write the HTML.

## Workflow

1. Compute every figure with pandas first and print the headline table. Never type a number you did not compute.
2. Build the page from those numbers.
3. Save with a contract: `r.save("report.html", require=dict(tabs=3, charts=5, kpis=4))`. If it raises `FAILED RUN`, fix the page; do not ship it.
4. Report the counts that `save()` prints (tabs, charts, KPI cards) when you hand over.

## Quick start

```python
import pandas as pd

r = Report("Weekly Leadership Pack", "Week 13 | 3 lines", footer="Source: file, rows, definitions")
r.banner("Week 13 is partial (4 of 7 days).", "warn")              # every data caveat goes here
r.kpis([dict(label="Plant OEE", value="90.1%", sub="weighted by operating time", status="good", status_label="On target"),
        dict(label="Total loss", value="LKR 1.33 mn", sub="scrap + lost capacity")])

tabs = r.tabs()                                                     # or r.section("Title", lead="...") for a single page
t = tabs.tab("Director", lead="Two plain sentences: what this reader should do.")
t.figure(bar_chart(lines, {"OEE %": oee}, "OEE (%)", "Line", color_by_label=True),
         "OEE by line", "Two sentences on what it means for the plant.")
t.table(df, status_col="Status", filter_cols=["Line"], search=True, fmts={"Loss": fmt_money})

r.tally("notices", 7)                                                # optional: count something the contract can require
r.save("report.html", require=dict(tabs=3, charts=5, kpis=4, notices=7))
```

`examples/example_plant_dashboard.py` is a complete worked example (three tabs, ten charts, five KPI cards). The docstring at the top of `build_report.py` lists every function signature and option.

## Rules the module cannot enforce

- Every chart has labelled axes with units and a two-sentence caption saying what it means. The card heading is the chart title.
- Colour follows the entity: Line 1 is the same colour in every chart. A lone measure uses one colour. Never use dual axes; two measures of different scale get two charts.
- Do not invent reference lines. A target or threshold on a chart must come from the data or the user's prompt.
- Show partial periods, missing data and unit conversions in a banner and on the chart (dashed segment, shaded gap), not in a footnote.
- Word each status truthfully. A chip's colour comes from its words, so "Pass - closed by the wrong role" is a contradiction; use `status_map` to set a colour explicitly.
- Where something is not derivable from the data, use the exact limitation sentence your own task instructions give.
